const faq = [
    {
        question: "Nihil Anim Keffiyeh Helvetica?",
        answer: `<strong>Moon Tempor</strong><br/>
                    Aenean non nibh nec nunc aliquam iaculis. Ut quis suscipit nunc. Duis at lectus a est aliquam venenatis vitae eget arcu. Sed egestas felis eget convallis maximus.<br/><br/>
                 <strong>High Life Accusamus</strong><br/>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborumeiusmod.Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origincoffeenulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beerlaborewes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butchervicelomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synthnesciuntyou probably haven't heard of them accusamus labore sustainable VHS.<br/><br/>
                 <strong>Curabitur Maximus</strong><br/>Food truck quinoa nesciunt laborumeiusmod.Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origincoffeenulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beerlaborewes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butchervicelomo.<br/><br/>
                 <ol>
                    <li>Ut quis suscipit nunc</li>
                    <li>Duis at lectus a est aliquam</li>
                    <li>Aenean non nibh nec</li>
                    <li>Non cupidatat skateboard</li>
                 </ol>`,
    },
    {
        question: "Adding Content Life Accusamus?",
        answer: "Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terryrichardson ad squid. 3 wolf moon officia aute,non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborumeiusmod.Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origincoffeenulla assumenda shoreditch et.<br/><br/>Nihil anim keffiyeh helvetica, craft beerlaborewes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butchervicelomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synthnesciuntyou probably haven't heard of them accusamus labore sustainable VHS.",
    },
    {
        question: "Aenean Researches and Experiments?",
        answer: "Sunt aliqua put a bird on it squid single-origincoffeenulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beerlaborewes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butchervice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synthnesciuntyou probably haven't heard of them accusamus labore sustainable VHS.",
    },
    {
        question: "Proident Excepteur Butcher?",
        answer: " Tellus a sem condimentum, vitae convallis sapien feugiat. Aenean non nibh nec nunc aliquam iaculis. Ut quis suscipit nunc. Duis at lectus a est aliquam venenatis vitae eget arcu. Sed egestas felis eget convallis maximus.<br/><br/>Curabitur maximus, ligula vel sagittis iaculis, risus nisi tincidunt sem, ut ultricies libero nulla eu ligula. Nam ultricies mollis nulla, sed laoreet leo convallis ac. Mauris nisl risus, tincidunt ac diam aliquet, convallis pellentesque nisi. Nam sit amet libero at odio malesuada ultricies a vitae dolor. Cras in viverra felis, non consequat quam. Praesent a orci enim. Vivamus porttitor nisi at nisl egestas iaculis. Nullam commodo eget dui sollicitudin sagittis. Duis id nibh mollis, hendrerit metus consectetur, ullamcorper risus. Morbi elementum ultrices nunc, quis porta nisi ornare sit amet. ",
    },
    {
        question: "Raw Denim Aesthetic?",
        answer: "Aenean non nibh nec nunc aliquam iaculis. Ut quis suscipit nunc. Duis at lectus a est aliquam venenatis vitae eget arcu. Sed egestas felis eget convallis maximus. Curabitur maximus, ligula vel sagittis iaculis, risus nisi tincidunt sem, ut ultricies libero nulla eu ligula. Nam ultricies mollis nulla, sed laoreet leo convallis ac.<br/><br/>Mauris nisl risus, tincidunt ac diam aliquet, convallis pellentesque nisi. Nam sit amet libero at odio malesuada ultricies a vitae dolor.",
    },
    {
        question: "Aliquam Venenatis Vitae?",
        answer: "Squid single-origincoffeenulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beerlaborewes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butchervice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synthnesciuntyou probably haven't heard of them accusamus labore sustainable VHS.",
    },
    {
        question: "Venenatis Vitae Eget Arcu?",
        answer: " Tellus a sem condimentum, vitae convallis sapien feugiat. Aenean non nibh nec nunc aliquam iaculis. Ut quis suscipit nunc. Duis at lectus a est aliquam venenatis vitae eget arcu. Sed egestas felis eget convallis maximus. Curabitur maximus, ligula vel sagittis iaculis, risus nisi tincidunt sem, ut ultricies libero nulla eu ligula. Nam ultricies mollis nulla, sed laoreet leo convallis ac. Mauris nisl risus, tincidunt ac diam aliquet, convallis pellentesque nisi. Nam sit amet libero at odio malesuada ultricies a vitae dolor. Cras in viverra felis, non consequat quam. Praesent a orci enim. Vivamus porttitor nisi at nisl egestas iaculis. Nullam commodo eget dui sollicitudin sagittis. Duis id nibh mollis, hendrerit metus consectetur, ullamcorper risus. Morbi elementum ultrices nunc, quis porta nisi ornare sit amet. ",
    }
]

export default faq
